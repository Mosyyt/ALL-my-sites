import{a as n}from"./main-a0db48cd.js";export{n as asyncComponents};
