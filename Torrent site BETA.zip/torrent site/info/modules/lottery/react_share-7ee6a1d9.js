function e(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}var a=globalThis.react;const r=e(a);export{r as R,e as g,a as r};
