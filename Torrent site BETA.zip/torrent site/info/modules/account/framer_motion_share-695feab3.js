var r=globalThis["framer-motion"];export{r as f};
