var a=globalThis["react/jsx-runtime"],r=globalThis["@bc/ui"];export{r as _,a as r};
