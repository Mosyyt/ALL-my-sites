var r=globalThis["react-router-dom"];export{r};
