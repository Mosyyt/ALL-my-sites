var s=globalThis["lodash-es"];export{s as l};
