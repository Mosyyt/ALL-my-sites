import{o as a,r as s}from"./index-CfUAFsgc.js";import"./vendor-DArDimbV.js";export{a as onMessage,s as renderChat};
