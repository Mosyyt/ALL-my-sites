import {
    j as a,
    k as s
} from "./chunk-47df8c47.js";
const e = "/assets/BlackJackA.f17772ea.png",
    c = "/assets/BlackJackB.39850ec8.png",
    g = "/assets/SpeedBlackjack.3a7b41d4.png",
    n = "/assets/VipBlackjack.67b994b7.png",
    t = "/assets/OneBlackjack.7b0de011.png",
    d = "/assets/SpeedBaccarat.4e36e147.png",
    k = "/assets/Academy.06941e95.png",
    p = "/assets/DeadliestSea.ada67982.png",
    l = "/assets/DragonSlayer.d1468223.png",
    r = "/assets/DragonQuest.fbad6c32.png",
    b = "/assets/DoggyMiner.3d17e0de.png",
    o = "/assets/Hunter.5ad56279.png",
    i = "/assets/JohnWild.1fd9cf04.png",
    m = "/assets/Zombies.b3d80146.png",
    B = {
        blackJackAImg: e,
        blackJackBImg: c,
        blackJackSpeedImg: g,
        blackJackVipImg: n,
        blackJackOneImg: t,
        baccaratSpeedImg: d,
        blackJack: a,
        fastparity: s,
        academy: k,
        deadliestSea: p,
        dragonSlayer: l,
        dragonQuest: r,
        doggyMiner: b,
        hunter: o,
        johnWild: i,
        zombies: m
    };
export {
    B as a
};