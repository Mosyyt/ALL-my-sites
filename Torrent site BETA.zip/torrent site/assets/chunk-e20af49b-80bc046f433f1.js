const s = "/assets/copper.39898678.svg",
    a = "/assets/gold.92faf9c1.svg",
    e = "/assets/rich.8786d13b.png",
    t = "/assets/rich-close.4d046450.png",
    c = "/assets/silver.9f31a5f7.svg",
    p = "/assets/star.57fa51e4.png",
    o = "/assets/topwin.a65b35ca.png",
    r = {
        copper: s,
        gold: a,
        rich: e,
        silver: c,
        star: p,
        rich_close: t,
        topwin: o
    };
export {
    r as w
};