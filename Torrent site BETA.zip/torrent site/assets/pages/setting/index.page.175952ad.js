import {
    j as t
} from "../../chunk-a4af42e8.js";
import {
    r
} from "../../chunk-73e80d68.js";
import {
    l as m
} from "../../chunk-654ef298.js";
import "../../chunk-cf010ec4.js";
const e = r.lazy(() => m("modules/account").then(o => o.setting()));

function n() {
    return t.jsx(e, {})
}
export {
    n as Page
};