import {
    j as r
} from "../../chunk-a4af42e8.js";
import {
    r as t,
    R as i
} from "../../chunk-73e80d68.js";
import {
    dx as m
} from "../../chunk-b53b00e3.js";
import {
    i as p,
    B as a
} from "../../chunk-b894b9de.js";
import {
    l as s
} from "../../chunk-654ef298.js";
import "../../chunk-cf010ec4.js";
import "../../chunk-5bcb444f.js";
import "../../chunk-357b411e.js";
import "../../chunk-27d137a6.js";
import "../../chunk-03c302ce.js";
import "../../chunk-0e1ef679.js";
import "../../chunk-5fced113.js";
import "../../chunk-0e835458.js";
import "../../chunk-35f3c0e2.js";
import "../../chunk-c23b3c52.js";
import "../../chunk-e570733e.js";
import "../../chunk-68de7933.js";
import "../../chunk-07977b38.js";
import "../../chunk-47df8c47.js";
import "../../chunk-3dc03e47.js";
import "../../chunk-e20af49b.js";
import "../../chunk-6e6e4b85.js";
import "../../chunk-b8efc996.js";
import "../../chunk-000ed202.js";
import "../../chunk-78c5b721.js";
const e = m(() => s("modules/static").then(o => o.landing())),
    n = t.memo(() => r.jsx(e, {
        Footer: p
    })),
    d = i.memo(function({
        children: o
    }) {
        return r.jsx(a, {
            children: o
        })
    }),
    l = ({
        ctx: o
    }) => ({
        documentProps: Promise.resolve({
            title: o.urlPathname === "/landing/india" ? "BC.GAME India" : "",
            keywords: " ",
            description: " "
        })
    });
export {
    d as Layout, n as Page, l as onPageData
};