import {
    j as o
} from "../../chunk-a4af42e8.js";
import {
    dx as r
} from "../../chunk-b53b00e3.js";
import "../../chunk-73e80d68.js";
import {
    g as m
} from "../../chunk-7459b96e.js";
import {
    l as a
} from "../../chunk-654ef298.js";
import "../../chunk-cf010ec4.js";
const e = () => a("modules/lottery").then(t => t.lottery()),
    s = r(e);

function n() {
    return o.jsx(s, {})
}
const p = ({
    ctx: t
}) => ({
    documentProps: m(t.lang, "lottery")
});
export {
    n as Page, p as onPageData
};