import {
    j as s
} from "../../chunk-a4af42e8.js";
import {
    dx as r
} from "../../chunk-b53b00e3.js";
import "../../chunk-73e80d68.js";
import {
    l as t
} from "../../chunk-654ef298.js";
import "../../chunk-cf010ec4.js";
const m = r(() => t("modules/static").then(o => o.sponsorship())),
    p = () => s.jsx(m, {});
export {
    p as Page
};