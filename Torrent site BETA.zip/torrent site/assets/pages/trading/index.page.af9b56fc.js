import {
    j as e
} from "../../chunk-a4af42e8.js";
import {
    T as a
} from "../../chunk-ad4eb03c.js";
import "../../chunk-73e80d68.js";
import "../../chunk-654ef298.js";
import "../../chunk-cf010ec4.js";
const r = "/assets/trade-bg.019b6de7.png",
    t = () => e.jsx(a, {
        gameUnique: "detrade:trading",
        basename: "/",
        bgImage: r
    });
export {
    t as Page
};