import {
    j as o
} from "../../../chunk-a4af42e8.js";
import {
    T as a
} from "../../../chunk-ad4eb03c.js";
import "../../../chunk-73e80d68.js";
import "../../../chunk-654ef298.js";
import "../../../chunk-cf010ec4.js";
const r = "/assets/updown-bg.841548a8.png",
    t = () => o.jsx(a, {
        basename: "/trading",
        bgImage: r
    });
export {
    t as Page
};