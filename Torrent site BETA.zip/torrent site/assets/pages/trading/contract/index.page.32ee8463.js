import {
    j as a
} from "../../../chunk-a4af42e8.js";
import {
    T as t
} from "../../../chunk-ad4eb03c.js";
import "../../../chunk-73e80d68.js";
import "../../../chunk-654ef298.js";
import "../../../chunk-cf010ec4.js";
const r = "/assets/contract-bg.c9ed2aca.png",
    o = () => a.jsx(t, {
        basename: "/trading",
        bgImage: r
    });
export {
    o as Page
};