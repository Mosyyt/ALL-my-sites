import {
    j as o
} from "../../chunk-a4af42e8.js";
import {
    b as r
} from "../../chunk-2d134749.js";
import {
    a as t
} from "../../chunk-1d6a2d71.js";
import "../../chunk-73e80d68.js";
import "../../chunk-b53b00e3.js";
import "../../chunk-cf010ec4.js";
import "../../chunk-07977b38.js";
import "../../chunk-0e835458.js";
import "../../chunk-0e1ef679.js";
import "../../chunk-421da83a.js";
import "../../chunk-5bcb444f.js";
import "../../chunk-394d30c6.js";
import "../../chunk-420c54b8.js";

function i() {
    return o.jsx(t, {})
}
const m = ({
    ctx: p
}) => ({
    providersData: r()
});
export {
    i as Page, m as onPageData
};