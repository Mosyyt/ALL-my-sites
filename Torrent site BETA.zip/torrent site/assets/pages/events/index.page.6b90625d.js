import {
    j as r
} from "../../chunk-a4af42e8.js";
import {
    dx as t
} from "../../chunk-b53b00e3.js";
import {
    R as m
} from "../../chunk-73e80d68.js";
import {
    B as i,
    i as p
} from "../../chunk-b894b9de.js";
import {
    l as s
} from "../../chunk-654ef298.js";
import "../../chunk-cf010ec4.js";
import "../../chunk-5bcb444f.js";
import "../../chunk-357b411e.js";
import "../../chunk-27d137a6.js";
import "../../chunk-03c302ce.js";
import "../../chunk-0e1ef679.js";
import "../../chunk-5fced113.js";
import "../../chunk-0e835458.js";
import "../../chunk-35f3c0e2.js";
import "../../chunk-c23b3c52.js";
import "../../chunk-e570733e.js";
import "../../chunk-68de7933.js";
import "../../chunk-07977b38.js";
import "../../chunk-47df8c47.js";
import "../../chunk-3dc03e47.js";
import "../../chunk-e20af49b.js";
import "../../chunk-6e6e4b85.js";
import "../../chunk-b8efc996.js";
import "../../chunk-000ed202.js";
import "../../chunk-78c5b721.js";
const e = t(() => s("modules/events").then(o => o.Events()));

function n() {
    return r.jsx(e, {})
}
const a = m.memo(function({
    children: o
}) {
    return r.jsx(i, {
        footer: r.jsx(p, {}),
        children: o
    })
});
export {
    a as Layout, n as Page
};