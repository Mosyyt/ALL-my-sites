import {
    j as s
} from "../../chunk-a4af42e8.js";
import {
    r as o
} from "../../chunk-73e80d68.js";
import {
    l as r
} from "../../chunk-654ef298.js";
import "../../chunk-cf010ec4.js";
const e = o.lazy(() => r("modules/games").then(m => m.asyncComponents.Japarot())),
    a = o.memo(() => s.jsx(o.Suspense, {
        children: s.jsx(e, {})
    }));
export {
    a as Page
};