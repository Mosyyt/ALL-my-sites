import {
    j as o
} from "../../chunk-a4af42e8.js";
import {
    r as e
} from "../../chunk-73e80d68.js";
import {
    a as n
} from "../../chunk-b53b00e3.js";
import {
    g as s
} from "../../chunk-7459b96e.js";
import {
    s as a
} from "../../chunk-1371f12f.js";
import "../../chunk-cf010ec4.js";
import "../../chunk-654ef298.js";

function m() {
    return e.useEffect(() => {
        n.emit("ad_track", "other_events", {
            e: "enterEventCenter"
        })
    }, []), o.jsx(a, {})
}
const i = ({
    ctx: r
}) => {
    const {
        lang: t
    } = r;
    return {
        documentProps: s(t, "bonus")
    }
};
export {
    m as Page, i as onPageData
};