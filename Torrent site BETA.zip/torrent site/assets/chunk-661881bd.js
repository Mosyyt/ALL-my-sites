import {
    _
} from "./chunk-cf010ec4.js";
import {
    dx as r,
    __tla as a
} from "./chunk-b53b00e3.js";
import "./chunk-73e80d68.js";
let t, o = Promise.all([(() => {
    try {
        return a
    } catch (l) {}
})()]).then(async () => {
    t = r(() => _(() =>
        import ("./ContestMain.a4cfa744.js"), ["assets/ContestMain.a4cfa744.js", "assets/chunk-a4af42e8.js", "assets/chunk-73e80d68.js", "assets/chunk-b53b00e3.js", "assets/chunk-cf010ec4.js", "assets/chunk-5bcb444f.js", "assets/chunk-644603d0.js", "assets/chunk-e20af49b.js", "assets/ContestMain.bcd14d22.css"]))
});
export {
    t as C, o as __tla
};