import {
    j as s
} from "./chunk-a4af42e8.js";
import {
    r as j,
    R as es
} from "./chunk-73e80d68.js";
import {
    ev as m,
    cw as D,
    cx as as,
    d0 as P,
    e5 as f,
    e9 as T,
    ci as p,
    cu as u,
    ez as N,
    dr as W,
    cJ as k,
    ct as ns,
    cg as is,
    dL as _,
    dg as S,
    ed as ts,
    cl as ls,
    dK as z,
    dQ as R,
    ds as E,
    cT as rs,
    aC as cs,
    cB as os,
    cA as ds,
    c_ as ms
} from "./chunk-b53b00e3.js";
import {
    c as y
} from "./chunk-5bcb444f.js";
import {
    u as v,
    c as b,
    C as L,
    T as hs
} from "./chunk-644603d0.js";
import {
    w as I
} from "./chunk-e20af49b.js";
import "./chunk-cf010ec4.js";
const xs = [I.gold, I.silver, I.copper],
    js = ({
        num: e
    }) => e < 4 ? s.jsx("div", {
        className: "position",
        children: s.jsx("img", {
            className: "user-ico",
            src: xs[e - 1]
        })
    }) : s.jsx("div", {
        className: "position",
        children: s.jsx("div", {
            children: N.numberOrdinal(e)
        })
    }),
    M = ({
        dat: e
    }) => {
        const n = v(),
            a = n.wagerCurrency,
            i = f(),
            t = T(!0);
        return s.jsxs("div", {
            className: "item",
            children: [s.jsx(js, {
                num: e.rank
            }), s.jsx("div", {
                className: "user-td",
                children: s.jsx(p.UserInfo, {
                    userId: e.userId,
                    name: e.player
                })
            }), s.jsx("div", {
                className: "wager",
                children: s.jsx("span", {
                    className: "coin",
                    children: t.amount2localStr(new u(e.wager), a)
                })
            }), s.jsxs("div", {
                className: "prize flex-middle",
                children: [s.jsx("span", {
                    className: "coin",
                    children: t.amount2localStr(new u(e.totalBonus), a)
                }), !i && s.jsxs("div", {
                    className: "percent",
                    children: ["(", N.numPercent(n.userBonusRate[e.rank - 1]), ")"]
                })]
            })]
        })
    },
    H = () => {
        const {
            t: e
        } = m();
        return s.jsxs("div", {
            className: "list-head item",
            children: [s.jsx("div", {
                className: "position",
                children: "#"
            }), s.jsx("div", {
                className: "user-td",
                children: e("Player")
            }), s.jsx("div", {
                className: "wager",
                children: e("Wagered")
            }), s.jsx("div", {
                className: "prize",
                children: e("Prize")
            })]
        })
    },
    ps = ({
        children: e,
        active: n = !1
    }) => s.jsxs("div", {
        className: "active-icon",
        children: [s.jsx("svg", {
            className: "bg",
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 81 32",
            children: s.jsx("path", {
                d: "M1.28 0h78.201c0.707 0 1.28 0.573 1.28 1.28 0 0.26-0.079 0.513-0.227 0.727l-10.079 14.603c-0.325 0.47-0.298 1.099 0.065 1.541l9.676 11.756c0.449 0.546 0.371 1.352-0.175 1.802-0.229 0.189-0.517 0.292-0.813 0.292h-77.929c-0.707 0-1.28-0.573-1.28-1.28v-29.44c0-0.707 0.573-1.28 1.28-1.28z"
            })
        }), n && s.jsx(k, {
            name: "Loading"
        }), s.jsx("div", {
            className: "label",
            children: e
        })]
    }),
    us = ({
        isActive: e = !1,
        startTime: n,
        endTime: a,
        list: i,
        preEndTime: t,
        preStartTime: l,
        preList: r
    }) => {
        const {
            t: c
        } = m();
        return s.jsxs("div", {
            className: y(F, "contest-table-wrap", e && "is-active"),
            children: [s.jsxs("div", {
                className: "title",
                children: [s.jsx(ps, {
                    active: e,
                    children: c(e ? "Active" : "Completed")
                }), s.jsxs("div", {
                    className: "time",
                    children: [n.toLocaleDateString(), " ~ ", a.toLocaleDateString()]
                }), s.jsx("button", {
                    className: "history-btn",
                    onClick: () => W.push(s.jsx(vs, {
                        preStartTime: l,
                        preEndTime: t,
                        historyList: r
                    })),
                    children: c("History")
                })]
            }), s.jsxs("div", {
                className: "list",
                children: [s.jsx(H, {}), i.map((d, o) => s.jsx(M, {
                    dat: d
                }, o))]
            })]
        })
    },
    vs = j.memo(function({
        preStartTime: e,
        preEndTime: n,
        historyList: a
    }) {
        const {
            t: i
        } = m();
        return s.jsxs(D, {
            className: gs,
            title: " ",
            children: [s.jsx(as, {
                children: s.jsxs("div", {
                    className: "dialog-title-time",
                    children: [s.jsx("p", {
                        className: "t",
                        children: i("History")
                    }), s.jsxs("p", {
                        className: "d",
                        children: [e.toLocaleDateString(), " ~", " ", n.toLocaleDateString()]
                    })]
                })
            }), s.jsx(P, {
                className: F,
                children: s.jsxs("div", {
                    className: "list",
                    children: [s.jsx(H, {}), a.map((t, l) => s.jsx(M, {
                        dat: t
                    }, l))]
                })
            })]
        })
    }),
    gs = "hsdnehp",
    F = "c1gh2bs4",
    Ns = "/assets/img1.5de6da53.png",
    ys = "/assets/star.67aee783.png",
    ws = "/assets/grass.f796a34c.png",
    U = "/assets/grass_left.879ac968.svg",
    K = "/assets/grass_right.34ab2d71.svg",
    bs = "/assets/trophy.424f8523.png",
    fs = {
        img1: Ns,
        star: ys,
        grass: ws,
        grass_left: U,
        grass_right: K,
        grass_left_w: U,
        grass_right_w: K,
        trophy: bs
    },
    C = es.memo(({
        name: e,
        value: n,
        line: a = !0
    }) => s.jsx("div", {
        className: "count-item",
        children: s.jsxs("div", {
            className: "count-panel",
            children: [s.jsx("div", {
                className: "count-value",
                children: N.numberZeroize(n)
            }), s.jsx("div", {
                className: "count-name",
                children: e
            })]
        })
    })),
    Y = ({
        endTime: e,
        className: n = ""
    }) => {
        const {
            t: a
        } = m();
        return s.jsxs("div", {
            className: y(Ts, n),
            children: [s.jsx("div", {
                className: "title tc",
                children: a("Time Remaining")
            }), s.jsx(ns, {
                endTime: e,
                onEnd: () => setTimeout(b.loadByContestType, 5e3),
                children: ({
                    days: i,
                    hours: t,
                    minutes: l,
                    seconds: r
                }) => s.jsxs("div", {
                    className: "contest-countdown",
                    children: [i > 0 && s.jsx(C, {
                        name: "DAYS",
                        value: i
                    }), s.jsx(C, {
                        name: a("Hours"),
                        value: t
                    }), s.jsx(C, {
                        name: a("Minutes"),
                        value: l,
                        line: i <= 0
                    }), i <= 0 && s.jsx(C, {
                        name: a("Seconds"),
                        value: r,
                        line: !1
                    })]
                })
            })]
        })
    },
    Ts = "c1ddvyut",
    Cs = "/assets/winner.007b47b1.png";

function _s() {
    const e = T(!0),
        {
            wagerCurrency: n
        } = v();
    return a => e.amount2localStr(new u(a), n)
}

function O(e) {
    return e == 0 || e > 50 ? "50th+" : N.numberOrdinal(e)
}
const Ss = s.jsx("svg", {
        viewBox: "0 0 32 32",
        xmlns: "http://www.w3.org/2000/svg",
        className: "avatar-icon",
        children: s.jsx("path", {
            fill: "#ffd308",
            d: "M27.924 14.807l-4.892 11.74h-14.063l-4.892-11.74c-1.198-0.105-2.14-1.099-2.14-2.324 0-1.294 1.049-2.344 2.344-2.344s2.344 1.049 2.344 2.344c0 0.498-0.157 0.957-0.421 1.336 0.827 1.307 2.274 2.18 3.937 2.18 2.182 0 3.999-1.497 4.522-3.516l0.035-0.197 0.131-2.472c-0.698-0.406-1.172-1.153-1.172-2.019 0-1.295 1.049-2.344 2.344-2.344s2.344 1.049 2.344 2.344c0 0.866-0.474 1.613-1.172 2.019l0.082 2.434 0.084 0.235c0.523 2.018 2.341 3.516 4.522 3.516 1.663 0 3.109-0.873 3.937-2.18-0.264-0.379-0.421-0.839-0.421-1.336 0-1.294 1.049-2.344 2.344-2.344s2.344 1.049 2.344 2.344c0 1.225-0.942 2.218-2.14 2.324z"
        })
    }),
    zs = s.jsx("svg", {
        viewBox: "0 0 32 32",
        xmlns: "http://www.w3.org/2000/svg",
        className: "title-icon",
        children: s.jsx("path", {
            fill: "#ffd308",
            d: "M27.924 14.807l-4.892 11.74h-14.063l-4.892-11.74c-1.198-0.105-2.14-1.099-2.14-2.324 0-1.294 1.049-2.344 2.344-2.344s2.344 1.049 2.344 2.344c0 0.498-0.157 0.957-0.421 1.336 0.827 1.307 2.274 2.18 3.937 2.18 2.182 0 3.999-1.497 4.522-3.516l0.035-0.197 0.131-2.472c-0.698-0.406-1.172-1.153-1.172-2.019 0-1.295 1.049-2.344 2.344-2.344s2.344 1.049 2.344 2.344c0 0.866-0.474 1.613-1.172 2.019l0.082 2.434 0.084 0.235c0.523 2.018 2.341 3.516 4.522 3.516 1.663 0 3.109-0.873 3.937-2.18-0.264-0.379-0.421-0.839-0.421-1.336 0-1.294 1.049-2.344 2.344-2.344s2.344 1.049 2.344 2.344c0 1.225-0.942 2.218-2.14 2.324z"
        })
    }),
    $ = j.memo(function() {
        const {
            t: e
        } = m(), n = _s(), {
            prizeAmount: a
        } = v();
        return s.jsxs("div", {
            className: Ls,
            children: [s.jsx("div", {
                className: "trophy",
                children: s.jsx("img", {
                    src: fs.trophy
                })
            }), s.jsxs("div", {
                children: [s.jsx("div", {
                    className: "type ttc",
                    children: e("Daily")
                }), s.jsx("div", {
                    className: "title",
                    children: e("Contest prize pool")
                }), s.jsx("div", {
                    className: "prize-amount",
                    children: s.jsx(is, {
                        format: n,
                        children: a
                    })
                })]
            })]
        })
    }),
    Ls = "p185pbp2",
    G = () => {
        const {
            t: e
        } = m(), n = ts();
        return s.jsxs("div", {
            className: y(Is, "contest-nologin"),
            children: [s.jsx("div", {
                className: "text",
                children: e("Who's the invincible champion at the high table? Let's see what a badass you can be!")
            }), s.jsx(ls, {
                type: "conic",
                className: "breathe",
                onClick: () => n("#/login"),
                children: e("Participate Now")
            })]
        })
    },
    Is = "nx34knj",
    J = j.memo(function() {
        const {
            t: e
        } = m(), n = f(), a = T(!0), i = _(), {
            rank: t,
            wager: l,
            wagerCurrency: r,
            userBonusRate: c,
            activeList: d
        } = v();
        let o = 1;
        t == 0 ? o = c.length : t == 1 ? o = 1 : t <= c.length ? o = t - 1 : o = c.length;
        let h = 0,
            w = null;
        d.length > o - 1 && (w = d[o - 1]), w && (h = w.wager - l);
        const x = a.amount2localStr(new u(h), r),
            g = `${e("Top")} ${o}`;
        return n ? s.jsxs("div", {
            className: y(Q, "contest-user-info"),
            children: [s.jsxs("div", {
                className: "head",
                children: [s.jsx(p.Avatar, {
                    userId: i.userId,
                    name: i.name
                }), s.jsx("div", {
                    className: "user-name",
                    children: i.name
                })]
            }), s.jsxs("div", {
                className: "box2-wrap",
                children: [s.jsxs("div", {
                    className: "box2 position",
                    children: [s.jsx("div", {
                        className: "label",
                        children: e("My Position")
                    }), s.jsx("div", {
                        className: "value",
                        children: O(t)
                    })]
                }), s.jsxs("div", {
                    className: "box2 wagered",
                    children: [s.jsx("div", {
                        className: "label",
                        children: e("Wagered")
                    }), s.jsx("div", {
                        className: "value",
                        children: a.amount2localStr(new u(l), r)
                    })]
                })]
            }), t != 1 && s.jsx("div", {
                className: "scale-text reach",
                children: s.jsx("div", {
                    className: "tc flex-middle",
                    children: s.jsxs(S, {
                        wager_number: x,
                        top: g,
                        i18nKey: "trans.mainpage.wager.desc",
                        children: ["Wager ", s.jsx("div", {
                            className: "coin-fait",
                            children: {
                                wager_number: x
                            }
                        }), " To reach ", s.jsx("span", {
                            className: "color-top ttu",
                            children: {
                                top: g
                            }
                        })]
                    })
                })
            })]
        }) : s.jsxs("div", {
            className: y(Q, "contest-user-info"),
            children: [s.jsxs("div", {
                className: "user",
                children: [s.jsx("div", {
                    className: "head",
                    children: s.jsx(p.Avatar, {
                        userId: i.userId,
                        name: i.name
                    })
                }), s.jsx("div", {
                    className: "user-name",
                    children: i.name
                })]
            }), s.jsxs("div", {
                className: "position myinfo-item",
                children: [s.jsx("div", {
                    className: "label",
                    children: e("My Position")
                }), s.jsx("div", {
                    className: "value",
                    children: O(t)
                })]
            }), s.jsxs("div", {
                className: "wager myinfo-item",
                children: [s.jsx("div", {
                    className: "label",
                    children: e("Wagered")
                }), s.jsx("div", {
                    className: "value",
                    children: a.amount2localStr(new u(l), r)
                })]
            }), t != 1 && s.jsx("div", {
                className: "reach myinfo-item",
                children: s.jsx("div", {
                    className: "flex-middle",
                    children: s.jsxs(S, {
                        wager_number: x,
                        top: g,
                        i18nKey: "trans.mainpage.wager.desc",
                        children: ["Wager ", s.jsx("div", {
                            className: "coin-fait",
                            children: {
                                wager_number: x
                            }
                        }), " To reach ", s.jsx("span", {
                            className: "color-top ttu",
                            children: {
                                top: g
                            }
                        })]
                    })
                })
            })]
        })
    }),
    Q = "m1ri3hr6",
    Z = j.memo(function() {
        const {
            t: e
        } = m(), {
            prevList: n,
            wagerCurrency: a,
            userBonusRate: i
        } = v();
        if (n.length == 0) return null;
        const t = n[0];
        let {
            userId: l,
            player: r,
            totalBonus: c
        } = t;
        const d = _(),
            o = T(!0),
            h = d.bonusCurrencyName !== "BCD";
        return s.jsxs("div", {
            className: y(Bs, "champion-wrap"),
            children: [s.jsxs("div", {
                className: "img-winner",
                children: [s.jsx("img", {
                    src: Cs,
                    alt: ""
                }), s.jsx("p", {
                    children: e("Winner")
                })]
            }), s.jsxs("div", {
                className: "champion-layout",
                children: [s.jsx(p.UserInfo, {
                    className: "head",
                    userId: l,
                    name: r,
                    showName: !1,
                    children: Ss
                }), s.jsxs("div", {
                    className: "content-box",
                    children: [s.jsxs("div", {
                        className: "champion__title",
                        children: [zs, s.jsx("div", {
                            className: "contest-ml",
                            children: e("Last Champion")
                        })]
                    }), s.jsx(p.UserInfo, {
                        className: "user-name",
                        userId: l,
                        name: r,
                        avatar: !1
                    }), s.jsxs("div", {
                        className: "profit",
                        children: [s.jsx("div", {
                            className: "profit-name",
                            children: e("Profit")
                        }), h ? s.jsxs(s.Fragment, {
                            children: [s.jsx(p.CoinIcon, {
                                name: d.bonusCurrencyName
                            }), s.jsx("span", {
                                className: "amount",
                                children: o.amount2localStr(new u(c), a)
                            })]
                        }) : s.jsx(s.Fragment, {
                            children: a === "BCD" ? s.jsxs(s.Fragment, {
                                children: [s.jsx(p.CoinIcon, {
                                    name: "BCD"
                                }), " ", s.jsx("span", {
                                    className: "amount",
                                    children: o.amount2localStr(new u(c), a)
                                })]
                            }) : s.jsx(p.CoinFormat, {
                                className: "prize-coin",
                                name: a,
                                amount: c,
                                showName: !1,
                                icon: !0
                            })
                        }), s.jsxs("div", {
                            className: "percent",
                            children: ["(", N.numPercent(i[0]), ")"]
                        })]
                    })]
                })]
            })]
        })
    }),
    Bs = "cwyxl3p",
    As = j.memo(function({
        type: e
    }) {
        const n = f(),
            a = _(),
            {
                endTime: i,
                startTime: t,
                activeList: l,
                prevStartTime: r,
                prevEndTime: c,
                prevList: d
            } = v();
        return s.jsxs("div", {
            className: Ds,
            children: [n ? s.jsxs("div", {
                className: "contest__top",
                children: [s.jsx($, {}), s.jsx("div", {
                    className: "scale-wrap",
                    children: s.jsx(Y, {
                        className: "bg-box",
                        endTime: i.getTime()
                    })
                }), s.jsx(Z, {}), a.login ? s.jsx("div", {
                    className: "page-userinfo-contest",
                    children: s.jsx(J, {})
                }) : s.jsx(G, {})]
            }) : s.jsxs(s.Fragment, {
                children: [s.jsxs("div", {
                    className: `contest__top ${a.login?"":"nologin"}`,
                    children: [s.jsx($, {}), a.login ? s.jsx(Y, {
                        className: "bg-box",
                        endTime: i.getTime()
                    }) : s.jsx(G, {}), s.jsx(Z, {})]
                }), a.login && s.jsx("div", {
                    className: "page-userinfo-contest",
                    children: s.jsx(J, {})
                })]
            }), s.jsx(us, {
                isActive: !0,
                startTime: t,
                endTime: i,
                list: l,
                preStartTime: r,
                preEndTime: c,
                preList: d
            })]
        })
    }),
    Ds = "cplgt7d",
    Ps = () => {
        const {
            t: e
        } = m(), n = v();
        let {
            wagerCurrency: a,
            participateCurrency: i,
            contestType: t,
            startTime: l,
            endTime: r,
            userBonusRate: c
        } = n;
        const d = z.getAlias(a),
            o = i.map(x => z.getAlias(x)).join(", "),
            h = {
                [L.DAILY]: e("Daily"),
                [L.WEEKLY]: e("Weekly"),
                [L.MONTHLY]: e("Monthly")
            }[t],
            w = R(async () => (await n.inited, s.jsxs("div", {
                children: [s.jsx("h2", {
                    children: e("Rules-{{type_name}} Wagering Contest", {
                        type_name: h
                    })
                }), s.jsxs("div", {
                    className: "help-content",
                    children: [s.jsxs("p", {
                        className: "cl-primary",
                        children: [l.toLocaleDateString(), " ~ ", r.toLocaleDateString()]
                    }), s.jsxs("ol", {
                        children: [s.jsxs("li", {
                            children: ["1. ", e("The contest prize pool closely depends on the bankroll, the more players bet the bigger it grows. Current prize pool will be showed on the Contest page.")]
                        }), s.jsxs("li", {
                            children: ["2. ", e("{{number}} most wagering players carve up the prize pool.", {
                                number: c.length.toString()
                            })]
                        }), s.jsxs("li", {
                            children: ["3. ", e("This Contest support wagering in : {{supports}}", {
                                supports: o
                            })]
                        }), s.jsxs("li", {
                            children: ["4. ", e("You can wager in any cryptocurrencies above, and they all will be switched to USDT at the current rate.")]
                        }), s.jsxs("li", {
                            children: ["5. ", e("All prizes will be sent in {{currency_name}}", {
                                currency_name: z.getAlias(d)
                            }), "."]
                        }), s.jsxs("li", {
                            children: ["6. ", e("Prizes will be sent on Notice page as the Contest ends.")]
                        }), s.jsxs("li", {
                            children: ["7. ", e("{{host}} reserves the right to exclude players who have violated our rules at any stage of the Contest.", {
                                host: E.buildHost
                            })]
                        }), s.jsxs("li", {
                            children: ["8. ", e("{{host}} reserves the right to change any rules and conditions at its sole discretion and without prior notice.", {
                                host: E.buildHost
                            })]
                        })]
                    }), s.jsxs("p", {
                        className: "tc",
                        children: ["\u{1F31F}\u{1F31F} ", e("Good luck and have fun!"), " \u{1F31F}\u{1F31F}"]
                    }), s.jsx("h2", {
                        children: e("Prize Calculation Formula")
                    }), s.jsx("ul", {
                        children: c.map((x, g) => {
                            const B = N.numberOrdinal(g + 1),
                                A = N.numPercent(x);
                            return s.jsx("li", {
                                children: s.jsxs(S, {
                                    number1: B,
                                    number2: A,
                                    typeName: h,
                                    i18nKey: "trans.mainpage.prize.pool",
                                    children: [s.jsx("span", {
                                        children: {
                                            number1: B
                                        }
                                    }), " place \u2013 ", s.jsx("span", {
                                        children: {
                                            number2: A
                                        }
                                    }), " of the ", s.jsx("span", {
                                        children: {
                                            typeName: h
                                        }
                                    }), " Contest prize pool"]
                                })
                            }, g)
                        })
                    })]
                })]
            })));
        return s.jsx(D, {
            title: e("Rules"),
            children: s.jsx(P, {
                className: ks,
                children: w
            })
        })
    },
    Ws = () => W.push(s.jsx(Ps, {})),
    ks = "wo83y4l",
    q = 2,
    V = {
        from: {
            y: 10,
            opacity: 0
        },
        enter: {
            y: 0,
            opacity: 1
        }
    },
    X = j.memo(() => {
        f();
        const e = v(),
            [n, a] = j.useState(() => b.loadByContestType());
        j.useEffect(() => {
            const l = setInterval(() => {
                    b.loadByContestType()
                }, 12e4),
                r = setInterval(() => {
                    e.prizeAmount += e.prizePoolChangeRate * q
                }, q * 1e3);
            return () => {
                clearInterval(l), clearInterval(r)
            }
        }, []);
        const i = e.supportType.map(l => {
                const r = l.toUpperCase(),
                    c = hs[r];
                return {
                    label: l,
                    value: c
                }
            }),
            t = R(async () => (await b.loadByContestType(), s.jsx(cs.div, {
                initial: V.from,
                animate: V.enter,
                children: s.jsx(As, {
                    type: e.contestType
                })
            })), [e.contestType], {
                loadingNode: s.jsx(rs, {
                    className: ss
                })
            });
        return s.jsx(os, {
            errorComponent: () => s.jsx(ds, {
                type: "offline"
            }),
            children: s.jsxs("div", {
                id: "contest",
                className: y(ss),
                children: [e.supportType.length > 1 ? s.jsx("div", {
                    className: "contest__tab",
                    children: s.jsx(ms, {
                        className: "contest__tab__nav",
                        value: e.contestType,
                        onChange: l => a(b.loadByContestType(l)),
                        options: i,
                        children: ({
                            option: l,
                            active: r
                        }) => s.jsx("button", {
                            className: r ? "is-active nav-item" : "nav-item",
                            children: s.jsx("div", {
                                className: "label ttc",
                                children: l.label
                            })
                        })
                    })
                }) : null, e.supportType.length != 0 && s.jsx(k, {
                    name: "Help",
                    className: "contest__rules",
                    onClick: Ws
                }), t]
            })
        })
    }),
    ss = "cmye78j";
export {
    X as ContestMain, X as
    default
};