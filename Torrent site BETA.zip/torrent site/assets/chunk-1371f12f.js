import {
    r as e
} from "./chunk-73e80d68.js";
import {
    l as o
} from "./chunk-654ef298.js";
const i = () => o("modules/bonus");

function a(s) {
    return e.lazy(async function() {
        const {
            asyncComponents: n
        } = await i();
        return n[s]()
    })
}
const r = a("BcdTipsEnter"),
    t = a("BindBonusEvents"),
    u = a("BonusEnter"),
    c = a("BonusNotify"),
    p = a("CatchCoco"),
    B = a("AutoNewSpin"),
    l = a("NewUserTask"),
    m = a("BcdRule"),
    R = a("BonusRakeback"),
    d = a("PCLinkEnter"),
    C = a("MobileLinkEnter"),
    f = a("MobileNumberEnter"),
    k = a("BonusPage"),
    b = a("BonusLink"),
    E = a("CoindropReceive"),
    S = a("CoindropSend"),
    g = a("BonusGameList"),
    y = a("SetCurrency"),
    L = a("RainPage"),
    N = a("RainSend"),
    P = a("CrashRain"),
    T = a("GameRain"),
    h = a("Recharge"),
    V = a("RollPage"),
    v = a("Spin"),
    w = a("Task"),
    G = a("Tip"),
    M = a("Vip"),
    A = a("VipLevel"),
    x = a("VipOffer");
export {
    B as A, r as B, E as C, T as G, C as M, l as N, d as P, L as R, y as S, w as T, M as V, P as a, p as b, c, u as d, f as e, t as f, m as g, R as h, b as i, S as j, g as k, N as l, h as m, V as n, v as o, G as p, A as q, x as r, k as s
};