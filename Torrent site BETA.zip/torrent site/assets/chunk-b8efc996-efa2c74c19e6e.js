import {
    eA as o
} from "./chunk-b53b00e3.js";
import "./chunk-73e80d68.js";
const r = o.proxy({
    chatOrNtice: void 0
});

function t() {
    return o.useProxy(r)
}
export {
    t as u
};