import os

key = os.urandom(8)
print(key.hex())